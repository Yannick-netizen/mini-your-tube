const params = new URLSearchParams(window.location.search);
const id = params.get("id");
const video = videos.find(v => v.id === id);

if (video) {
  const container = document.getElementById("video-player");
  container.innerHTML = `
    <video controls width="100%">
      <source src="${video.src}" type="video/mp4">
      Votre navigateur ne supporte pas la vidéo.
    </video>
    <h2>${video.title}</h2>
    <p>${video.description}</p>
  `;
} else {
  document.getElementById("video-player").innerText = "Vidéo introuvable.";
}
