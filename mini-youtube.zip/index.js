const container = document.getElementById("video-list");
videos.forEach(video => {
  const card = document.createElement("div");
  card.className = "video-card";
  card.innerHTML = `
    <a href="video.html?id=${video.id}">
      <img src="${video.thumbnail}" alt="${video.title}">
      <h3>${video.title}</h3>
    </a>
  `;
  container.appendChild(card);
});
