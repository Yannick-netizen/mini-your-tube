const videos = [
  {
    id: "1",
    title: "Ma première vidéo",
    description: "Ceci est une vidéo de test.",
    src: "https://www.w3schools.com/html/mov_bbb.mp4",
    thumbnail: "https://via.placeholder.com/320x180?text=Vidéo+1"
  },
  {
    id: "2",
    title: "Vidéo tutoriel",
    description: "Apprenez à coder une app YouTube.",
    src: "https://www.w3schools.com/html/movie.mp4",
    thumbnail: "https://via.placeholder.com/320x180?text=Vidéo+2"
  }
];
